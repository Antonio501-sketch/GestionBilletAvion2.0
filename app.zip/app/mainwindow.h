#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSqlDatabase>
#include <QDebug>
#include <QSqlQueryModel>

#include "QMessageBox"
#include "connexion_mysql.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:

    void on_pushButton_ajouterClient_clicked();

    void on_pushButton_filtrerVols_clicked();

    void on_pushButton_selectionnerVol_clicked();

    void on_pushButton_sign_clicked();
    void on_pushButton_login_clicked();

    void on_pushButton_login_valider_clicked();

    void on_pushButton_retour_clicked();

    void on_pushButton_retour_1_clicked();

private:
    Ui::MainWindow *ui;
    QSqlQueryModel *volModel = nullptr;

    int m_currentClientId = 0;

    void afficherVols(const QString &condition = "");

    void naviguerVersSelectionVol();

    void chargerFiltresAeroports();

    void naviguerVersAccueil();

};
#endif // MAINWINDOW_H
