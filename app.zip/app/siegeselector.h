#ifndef SIEGESELECTOR_H
#define SIEGESELECTOR_H

#include <QDialog>
#include <QPushButton>
#include <QGridLayout>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>

namespace Ui {
class SiegeSelector;
}

class SiegeSelector : public QDialog
{
    Q_OBJECT

public:
    explicit SiegeSelector(int idVol, QWidget *parent = nullptr);
    ~SiegeSelector();

    QString siegeSelectionne() const { return m_siegeSelectionne; }

private slots:
    void on_siege_clicked();

private:
    Ui::SiegeSelector *ui;
    int m_idVol;
    QString m_siegeSelectionne;

    void dessinerSchemaSieges();
    QList<QString> obtenirSiegesReserves(int idVol);

};

#endif // SIEGESELECTOR_H
