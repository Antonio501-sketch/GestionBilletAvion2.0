#include "siegeselector.h"
#include "ui_siegeselector.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QLabel>
#include <QMessageBox>

const int NB_RANGEES = 10;
const int NB_COLS = 6;
const QString sieges[] = {"A", "B", "C", "D", "E", "F"};

SiegeSelector::SiegeSelector(int idVol, QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::SiegeSelector),
    m_idVol(idVol)
{
    ui->setupUi(this);
    setModal(true);

    ui->label_infoVol->setText(QString("Sélectionnez votre siège pour le Vol #%1").arg(idVol));
    ui->pushButton_reserver->setEnabled(false);

    dessinerSchemaSieges();
}

SiegeSelector::~SiegeSelector()
{
    delete ui;
}

QList<QString> SiegeSelector::obtenirSiegesReserves(int idVol)
{
    QList<QString> reserves;
    QSqlQuery query;

    query.prepare("SELECT num_siège FROM BILLET WHERE id_vol = :idVol AND num_siège IS NOT NULL");
    query.bindValue(":idVol", idVol);

    if (query.exec()) {
        while (query.next()) {
            reserves.append(query.value(0).toString());
        }
    } else {
        qDebug() << "Erreur BDD (Sièges Réservés) : " << query.lastError().text();
    }
    return reserves;
}

void SiegeSelector::dessinerSchemaSieges()
{
    QList<QString> siegesReserves = obtenirSiegesReserves(m_idVol);

    // Assurez-vous que le QWidget est nommé "widget_siegeContainer"
    QGridLayout *layoutSieges = new QGridLayout(ui->widget_siegeContainer);

    // Ajoutez un espacement minimal pour une meilleure visualisation
    layoutSieges->setSpacing(5);

    for (int rangee = 1; rangee <= NB_RANGEES; ++rangee) {
        // Label de rangée (colonne 0)
        QLabel *labelRangee = new QLabel(QString::number(rangee));
        layoutSieges->addWidget(labelRangee, rangee, 0, Qt::AlignCenter);

        for (int col = 0; col < NB_COLS; ++col) {

            QString nomSiege = QString::number(rangee) + sieges[col];
            QPushButton *btn = new QPushButton(nomSiege);
            btn->setFixedSize(45, 45);

            // Stocke l'ID du siège et connecte le signal
            btn->setProperty("siege_id", nomSiege);
            btn->setObjectName(nomSiege);
            connect(btn, &QPushButton::clicked, this, &SiegeSelector::on_siege_clicked);

            // Appliquer les styles et états
            if (siegesReserves.contains(nomSiege)) {
                btn->setEnabled(false); // Siège réservé
                btn->setStyleSheet("background-color: darkred; color: white;");
            } else {
                btn->setStyleSheet("background-color: lightgreen;"); // Siège libre
            }

            // Gérer la disposition du couloir central
            int layoutCol = col + 1; // +1 pour la colonne du label de rangée
            if (col >= 3) layoutCol += 1; // Décalage pour le couloir

            layoutSieges->addWidget(btn, rangee, layoutCol);
        }
    }
}


// =================================================================
// 3. SLOTS (Gestion des Clics)
// =================================================================

// Le slot qui doit être mis à jour
void SiegeSelector::on_siege_clicked()
{
    QPushButton *btn = qobject_cast<QPushButton*>(sender());
    if (!btn) return;

    QString nouveauSiege = btn->property("siege_id").toString();

    // 1. Désélectionner l'ancien siège (Remplacement de la logique de recherche)
    if (!m_siegeSelectionne.isEmpty() && m_siegeSelectionne != nouveauSiege) {

        // --- NOUVEAU CODE CRITIQUE ---
        // 1a. Récupérer le QGridLayout du conteneur
        QGridLayout *layoutSieges = qobject_cast<QGridLayout*>(ui->widget_siegeContainer->layout());

        if (layoutSieges) {
            // 1b. Itérer sur tous les widgets du layout pour trouver l'ancien bouton
            for (int i = 0; i < layoutSieges->count(); ++i) {
                QLayoutItem *item = layoutSieges->itemAt(i);
                QPushButton *ancienBtn = qobject_cast<QPushButton*>(item->widget());

                // 1c. Si on trouve le bouton correspondant à l'ancienne sélection
                if (ancienBtn && ancienBtn->property("siege_id").toString() == m_siegeSelectionne) {
                    ancienBtn->setStyleSheet("background-color: lightgreen;"); // Retour à libre
                    break;
                }
            }
        }
        // --- FIN DU NOUVEAU CODE CRITIQUE ---
    }

    // 2. Traiter la nouvelle sélection
    if (m_siegeSelectionne != nouveauSiege) {
        // Nouvelle sélection
        m_siegeSelectionne = nouveauSiege;
        btn->setStyleSheet("background-color: blue; color: white;"); // Appliquer le style sélectionné
        ui->pushButton_reserver->setEnabled(true);
    } else {
        // Désélection (clic sur le même siège)
        m_siegeSelectionne.clear();
        btn->setStyleSheet("background-color: lightgreen;"); // Style libre
        ui->pushButton_reserver->setEnabled(false);
    }
}
