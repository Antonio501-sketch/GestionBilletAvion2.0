#ifndef CONNEXION_MYSQL_H
#define CONNEXION_MYSQL_H

#include "QSqlDatabase"
#include "QSqlQuery"
#include "QSqlError"
#include <QDebug>
#include <QMessageBox>
#include <QCryptographicHash>
#include <QSqlRecord>

static inline bool connexionbd()
{
    QSqlDatabase conn=QSqlDatabase::addDatabase("QMYSQL");
    conn.setHostName("127.0.0.1");
    conn.setUserName("root");
    conn.setDatabaseName("gestion_billet_avion");
    conn.setPort(3306);
    conn.setPassword("thegoatisback*");

    if(conn.open())
    {
        qDebug() << "Connexion à la base de données réussie!";
        return true;
    }else
    {
        qDebug() << "Échec de la connexion à la base de données:" << conn.lastError().text();
        return false;
    }
}

static inline QString hashPassword(const QString &password)
{
    // Utiliser SHA-256 pour le hachage
    QByteArray hash = QCryptographicHash::hash(password.toUtf8(), QCryptographicHash::Sha256);

    // Retourner le hash en hexadécimal
    return hash.toHex();

    // NOTE: Votre table MySQL utilise CHAR(60), il faudra s'assurer que le type
    // et la taille correspondent au hash généré (par exemple, utiliser VARCHAR(64)
    // pour un SHA-256 complet en hexadécimal si possible).
}

static inline int insertClient(const QString &nom,
                               const QString &prenom,
                               const QString &email,
                               const QString &numPasseport,
                               const QString &contact,
                               const QString &motDePasse)
{
    // Hachage du mot de passe avant l'insertion
    QString hashedPassword = hashPassword(motDePasse); // Assurez-vous que hashPassword() est accessible

    QSqlQuery query;

    // Préparation de la requête avec des placeholders
    query.prepare("INSERT INTO CLIENT (nom, prenom, email, num_passeport, contact, mot_de_passe_hache) "
                  "VALUES (:nom, :prenom, :email, :passeport, :contact, :hash)");

    // Lier les valeurs
    query.bindValue(":nom", nom);
    query.bindValue(":prenom", prenom);
    // Gérer les champs facultatifs (email, passeport, contact) qui peuvent être vides.
    // Si vide, lier NULL (ou une chaîne vide si la colonne le permet, ici on suppose chaîne vide)
    query.bindValue(":email", email);
    query.bindValue(":passeport", numPasseport);
    query.bindValue(":contact", contact);
    query.bindValue(":hash", hashedPassword);

    if (!query.exec()) {
        qDebug() << "Erreur lors de l'insertion du client:" << query.lastError().text();
        // Nous allons gérer l'affichage de l'erreur dans MainWindow, pas ici.
        return 0; // Retourne 0 en cas d'échec
    }

    // --- Récupération de l'ID généré ---
    int newClientId = query.lastInsertId().toInt();

    qDebug() << "Client inséré avec succès. ID:" << newClientId << " Email:" << email;
    return newClientId; // Retourne l'ID du nouveau client
}

static inline bool insertReservationEtBillet(int idClient, int idVol,
                                             const QString &siege,
                                             double prixTotal,
                                             const QString &typeTravel)
{
    // Récupère la connexion de base de données par défaut (doit être déjà ouverte)
    QSqlDatabase db = QSqlDatabase::database();
    if (!db.isOpen()) {
        qDebug() << "Erreur: Connexion BDD non ouverte.";
        return false;
    }

    // --- DÉBUT DE LA TRANSACTION ---
    db.transaction();
    QSqlQuery query;
    bool success = false;

    // 1. Insertion dans la table RESERVATION
    query.prepare("INSERT INTO reservation (id_client, statut, montant_total, type_travel) "
                  "VALUES (:idClient, 'Confirmée', :montant, :typeTravel)");
    query.bindValue(":idClient", idClient);
    query.bindValue(":montant", prixTotal);
    query.bindValue(":typeTravel", typeTravel);

    if (query.exec()) {
        // 2. Récupérer l'ID de la réservation nouvellement créée (Clé étrangère pour BILLET)
        int idReservation = query.lastInsertId().toInt();

        // 3. Insertion dans la table BILLET (avec le numéro de siège)
        QSqlQuery queryBillet;
        queryBillet.prepare("INSERT INTO BILLET (id_reservation, id_vol, num_siège) "
                            "VALUES (:idRes, :idVol, :siege)");
        queryBillet.bindValue(":idRes", idReservation);
        queryBillet.bindValue(":idVol", idVol);
        queryBillet.bindValue(":siege", siege);

        if (queryBillet.exec()) {
            success = true; // Les deux insertions ont réussi
        } else {
            qDebug() << "Erreur BDD (Billet):" << queryBillet.lastError().text();
        }
    } else {
        qDebug() << "Erreur BDD (Reservation):" << query.lastError().text();
    }

    // --- FIN DE LA TRANSACTION ---
    if (success) {
        db.commit(); // Valider les deux lignes
    } else {
        db.rollback(); // Annuler les deux lignes
    }
    return success;
}

static inline int authenticateClient(const QString &email, const QString &motDePasse)
{
    // 1. Hacher le mot de passe fourni par l'employé
    QString hashedPassword = hashPassword(motDePasse);

    QSqlQuery query;
    // 2. Requête pour trouver l'ID client par email ET mot de passe haché
    query.prepare("SELECT id_client FROM CLIENT "
                  "WHERE email = :email AND mot_de_passe_hache = :hash");

    query.bindValue(":email", email);
    query.bindValue(":hash", hashedPassword);

    if (query.exec() && query.next()) {
        // Succès : client trouvé
        int idClient = query.value(0).toInt();
        qDebug() << "Authentification réussie pour Email:" << email << " ID:" << idClient;
        return idClient; // Retourne l'ID du client ( > 0)
    } else {
        // Échec : client non trouvé ou mot de passe incorrect
        if (query.lastError().isValid()) {
            qDebug() << "Erreur BDD (Login):" << query.lastError().text();
        }
        return 0; // Retourne 0
    }
}

#endif // CONNEXION_MYSQL_H
