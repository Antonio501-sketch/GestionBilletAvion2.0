#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QTableView>
#include "siegeselector.h"
#include "connexion_mysql.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    qDebug() << QSqlDatabase::drivers();

    ui->tabWidget_gestion->tabBar()->hide();

    ui->tabWidget_gestion->setCurrentIndex(0);

    ui->tableView_vols->setSelectionBehavior(QAbstractItemView::SelectRows);

    QList<QPushButton*> retourButtons = this->findChildren<QPushButton*>();

    // 2. Parcourir la liste et connecter ceux dont le nom correspond à un critère
    for (QPushButton *button : retourButtons)
    {
        // 🚨 IMPORTANT : Assurez-vous que tous vos boutons de retour commencent par "pushButton_retour"
        if (button->objectName().startsWith("pushButton_retour"))
        {
            connect(button, &QPushButton::clicked,
                    this, &MainWindow::naviguerVersAccueil);
        }
    }

    chargerFiltresAeroports();
    afficherVols("");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_ajouterClient_clicked()
{
    // 1. Récupérer les données
    QString nom = ui->lineEdit_nomClient->text().trimmed();
    QString prenom = ui->lineEdit_prenomClient->text().trimmed();
    QString email = ui->lineEdit_emailClient->text().trimmed();
    QString passeport = ui->lineEdit_passeportClient->text().trimmed();
    QString contact = ui->lineEdit_contactClient->text().trimmed();
    QString password = ui->lineEdit_passwordClient->text();

    // 2. Validation simple
    if (nom.isEmpty() || prenom.isEmpty() || password.isEmpty())
    {
        QMessageBox::warning(this, "Champs Manquants", "Veuillez remplir le Nom, Prénom et Mot de Passe.");
        return;
    }

    // 3. Appel de la fonction d'insertion et récupération de l'ID
    // Remplace bool success = ... par int newClientId = ...
    int newClientId = insertClient(nom, prenom, email, passeport, contact, password);

    // 4. Traiter le résultat
    if (newClientId > 0)
    {
        // --- NOUVELLE LOGIQUE D'AUTHENTIFICATION ---
        m_currentClientId = newClientId; // **Stocke l'ID du client nouvellement créé**

        QMessageBox::information(this, "Succès", "Le client " + nom + " " + prenom + " a été enregistré et connecté !");

        // Vider les champs
        ui->lineEdit_nomClient->clear();
        ui->lineEdit_prenomClient->clear();
        ui->lineEdit_emailClient->clear();
        ui->lineEdit_passeportClient->clear();
        ui->lineEdit_contactClient->clear();
        ui->lineEdit_passwordClient->clear();

        // Naviguer vers l'onglet de sélection de vol
        naviguerVersSelectionVol();
        // --- FIN NOUVELLE LOGIQUE ---
    }
    else
    {
        // L'erreur est déjà affichée dans la sortie de débogage (qDebug)
        QMessageBox::information(this, "Échec", "L'enregistrement du client a échoué. Vérifiez si l'email ou le contact existe déjà.");
        m_currentClientId = 0;
    }
}


void MainWindow::on_pushButton_filtrerVols_clicked()
{
    QStringList conditions;

    // DÉPART
    int indexDepartPays = ui->comboBox_paysDepart->currentIndex();
    int indexDepartVille = ui->comboBox_villeDepart->currentIndex();
    int indexDepartAeroport = ui->comboBox_aeroportDepart->currentIndex();

    // On filtre uniquement si l'index est > 0 (si ce n'est pas le placeholder)
    if (indexDepartPays > 0) {
        QString departPays = ui->comboBox_paysDepart->currentText();
        // Le filtre est appliqué
        conditions << QString("AD.nom_pays = '%1'").arg(departPays);
    }
    if (indexDepartVille > 0) {
        QString departVille = ui->comboBox_villeDepart->currentText();
        conditions << QString("AD.nom_ville = '%1'").arg(departVille);
    }
    if (indexDepartAeroport > 0) {
        QString departAeroport = ui->comboBox_aeroportDepart->currentText();
        conditions << QString("AD.code_iata = '%1'").arg(departAeroport);
    }

    // ARRIVÉE
    int indexArriveePays = ui->comboBox_paysArrivee->currentIndex();
    int indexArriveeVille = ui->comboBox_villeArrivee->currentIndex();
    int indexArriveeAeroport = ui->comboBox_aeroportArrivee->currentIndex();

    if (indexArriveePays > 0) {
        QString arriveePays = ui->comboBox_paysArrivee->currentText();
        conditions << QString("AA.nom_pays = '%1'").arg(arriveePays);
    }
    if (indexArriveeVille > 0) {
        QString arriveeVille = ui->comboBox_villeArrivee->currentText();
        conditions << QString("AA.nom_ville = '%1'").arg(arriveeVille);
    }
    if (indexArriveeAeroport > 0) {
        QString arriveeAeroport = ui->comboBox_aeroportArrivee->currentText();
        conditions << QString("AA.code_iata = '%1'").arg(arriveeAeroport);
    }

    // FILTRES DE PRIX (inchangés)
    double prixMin = ui->lineEdit_prixMin->text().toDouble();
    double prixMax = ui->lineEdit_prixMax->text().toDouble();
    // ... (Logique de prix inchangée) ...
    if (prixMin > 0) {
        conditions << QString("V.prix_billet >= %1").arg(prixMin);
    }
    if (prixMax > 0 && prixMax >= prixMin) {
        conditions << QString("V.prix_billet <= %1").arg(prixMax);
    }


    QString finalCondition;
    if (!conditions.isEmpty()) {
        finalCondition = conditions.join(" AND ");
    }

    afficherVols(finalCondition);
}

void MainWindow::afficherVols(const QString &condition)
{
    if (!volModel) {
        volModel = new QSqlQueryModel(this);
    }

    // NOUVELLE REQUÊTE : Utilise les jointures pour Pays et Ville
    QString queryStr = "SELECT "
                       "V.id_vol, "                  // 0. ID du vol (caché)
                       "AD.nom_pays AS 'Pays Départ', "
                       "AD.nom_ville AS 'Ville Départ', "
                       "AA.nom_pays AS 'Pays Arrivée', "
                       "AA.nom_ville AS 'Ville Arrivée', "
                       "V.date_depart AS 'Date Départ', "
                       "V.heure_depart AS 'Heure Départ', "
                       "V.prix_billet AS 'Prix Billet', "
                       "V.classe AS 'Classe' "
                       "FROM VOL V "
                       "JOIN AEROPORT AD ON V.id_depart_aeroport = AD.id_aeroport "
                       "JOIN AEROPORT AA ON V.id_arrivee_aeroport = AA.id_aeroport";

    if (!condition.isEmpty()) {
        queryStr += " WHERE " + condition;
    }
    queryStr += " ORDER BY V.date_depart, V.heure_depart";

    // 1. Exécuter la requête
    volModel->setQuery(queryStr);

    // 2. Vérification des erreurs
    if (volModel->lastError().isValid()) {
        qDebug() << "Erreur BDD (Affichage Vols) : " << volModel->lastError().text();
    }

    // 3. Afficher les données dans le QTableView
    ui->tableView_vols->setModel(volModel);

    // 4. LOGIQUE DE VÉRIFICATION DES RÉSULTATS (NOUVEAU)

    // Récupérer le nombre de lignes
    int rowCount = volModel->rowCount();

    if (rowCount == 0) {
        // Cacher le tableau et afficher le message
        ui->tableView_vols->hide();
        ui->label_message_vol->setText("Ce que vous cherchez n'est pas encore disponible.");
        ui->label_message_vol->show();
    } else {
        // Afficher le tableau et cacher le message
        ui->tableView_vols->show();
        ui->label_message_vol->hide();

        // Mettre à jour l'affichage des colonnes (si nécessaire)
        ui->tableView_vols->hideColumn(0);
        ui->tableView_vols->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    }
}

void MainWindow::on_pushButton_selectionnerVol_clicked()
{
    QModelIndexList selection = ui->tableView_vols->selectionModel()->selectedRows();
    if (selection.isEmpty()) {
        QMessageBox::warning(this, "Sélection Requise", "Veuillez sélectionner un vol.");
        return;
    }

    // 1. Récupérer l'ID du vol
    QModelIndex index = selection.first();
    // (Assurez-vous que la colonne 0 contient l'ID du vol)
    int idVol = ui->tableView_vols->model()->data(ui->tableView_vols->model()->index(index.row(), 0)).toInt();

    // 2. Lancer la fenêtre de sélection de siège
    SiegeSelector dialog(idVol, this);

    // 'dialog.exec() == QDialog::Accepted' est vrai si l'utilisateur a cliqué sur 'Réserver' (qui appelle accept())
    if (dialog.exec() == QDialog::Accepted) {
        QString siege = dialog.siegeSelectionne();

        if (!siege.isEmpty()) {

            int idClientConnecte = m_currentClientId;

            // Vérification critique
            if (idClientConnecte <= 0) {
                QMessageBox::critical(this, "Erreur de Réservation", "Veuillez vous connecter ou vous inscrire avant de réserver.");
                return;
            }

            // Récupération du prix du vol depuis la BDD
            double prixVol = 0.0;
            QSqlQuery prixQuery;
            prixQuery.prepare("SELECT prix_billet FROM VOL WHERE id_vol = :idVol");
            prixQuery.bindValue(":idVol", idVol);

            if (prixQuery.exec() && prixQuery.next()) {
                prixVol = prixQuery.value(0).toDouble();
            } else {
                QMessageBox::critical(this, "Erreur BDD", "Impossible de récupérer le prix du vol.");
                return;
            }

            // --- 3. DÉCLENCHEMENT DE LA TRANSACTION BDD ---

            // Assurez-vous que la fonction insertReservationEtBillet est dans votre fichier de connexion_mysql
            bool reservationSuccess = insertReservationEtBillet(
                idClientConnecte,
                idVol,
                siege,
                prixVol,
                "aller_simple" // Ajuster le type de voyage
                );

            if (reservationSuccess) {
                QMessageBox::information(this, "Succès", QString("Réservation complétée ! Siège : %1. Total : %2 €")
                                                             .arg(siege).arg(prixVol));
                // Optionnel : Vous pouvez appeler ici une fonction pour rafraîchir l'affichage des vols.
            } else {
                QMessageBox::critical(this, "Échec", "La réservation a échoué en base de données.");
            }
        }
    }
}

// Slot pour le bouton LOGIN
void MainWindow::on_pushButton_login_clicked()
{
    // Remplacez '1' par l'index réel de l'onglet Login
    const int LOGIN_INDEX = 1;

    // Bascule vers l'onglet Login
    ui->tabWidget_gestion->setCurrentIndex(LOGIN_INDEX);
}

// Slot pour le bouton SIGN (Inscription)
void MainWindow::on_pushButton_sign_clicked()
{
    // Remplacez '2' par l'index réel de l'onglet Sign
    const int SIGN_INDEX = 2;

    // Bascule vers l'onglet Sign
    ui->tabWidget_gestion->setCurrentIndex(SIGN_INDEX);
}

void MainWindow::on_pushButton_login_valider_clicked()
{
    // 1. Récupérer les données
    QString email = ui->lineEdit_login_email->text().trimmed();
    QString password = ui->lineEdit_login_mdp->text();

    // 2. Validation simple
    if (email.isEmpty() || password.isEmpty())
    {
        QMessageBox::warning(this, "Champs Manquants", "Veuillez entrer l'Email et le Mot de Passe.");
        return;
    }

    // 3. Authentifier le client et récupérer l'ID
    int authenticatedClientId = authenticateClient(email, password);

    // 4. Traiter le résultat
    if (authenticatedClientId > 0)
    {
        // --- SUCCÈS : Stocker l'ID et Naviguer ---
        m_currentClientId = authenticatedClientId;

        QMessageBox::information(this, "Connexion Réussie", "Connexion réussie pour l'employé. ID Client: " + QString::number(m_currentClientId));

        // Vider les champs pour la sécurité
        ui->lineEdit_login_email->clear();
        ui->lineEdit_login_mdp->clear();

        // Naviguer vers l'onglet de sélection de vol
        naviguerVersSelectionVol();
    }
    else
    {
        // ÉCHEC : Mot de passe ou email incorrect
        QMessageBox::warning(this, "Échec de Connexion", "Email ou Mot de Passe incorrect. Réessayez.");
        m_currentClientId = 0;
    }
}

void MainWindow::naviguerVersSelectionVol()
{
    // Déterminez l'index de l'onglet de sélection de vol.
    // Si c'est le tout premier onglet (après l'onglet d'accueil/login/sign),
    // il est probablement à l'index 0, 3 ou 4.

    // IMPORTANT : Remplacez 'INDEX_DU_VOL' par l'index réel de votre onglet
    const int SELECTION_VOL_INDEX = 3; // <== MODIFIEZ CET INDEX

    // Vérification de sécurité: s'assurer qu'un client est bien connecté
    if (m_currentClientId > 0) {

        // Bascule vers l'onglet de sélection de vol
        ui->tabWidget_gestion->setCurrentIndex(SELECTION_VOL_INDEX);

        // Optionnel : Mettre à jour l'affichage dans l'onglet de vol
        // Si vous avez un QLabel pour afficher le nom du client connecté :
        // ui->label_client_connecte->setText(QString("Réservation pour le client ID : %1").arg(m_currentClientId));
    } else {
        // Ne devrait pas arriver si les slots de validation sont corrects
        QMessageBox::critical(this, "Erreur de Navigation", "Aucun client n'est actuellement connecté.");
    }
}


void MainWindow::chargerFiltresAeroports()
{
    // --- Requêtes BDD (inchangées) ---
    QSqlQuery queryPays("SELECT DISTINCT nom_pays FROM AEROPORT ORDER BY nom_pays");
    QSqlQuery queryVille("SELECT DISTINCT nom_ville FROM AEROPORT ORDER BY nom_ville");
    QSqlQuery queryAeroport("SELECT DISTINCT code_iata FROM AEROPORT ORDER BY code_iata");

    // --- Nettoyage des ComboBox ---
    ui->comboBox_paysDepart->clear();
    ui->comboBox_paysArrivee->clear();
    ui->comboBox_villeDepart->clear();
    ui->comboBox_villeArrivee->clear();
    ui->comboBox_aeroportDepart->clear();
    ui->comboBox_aeroportArrivee->clear();


    // --- AJOUT DES PLACEHOLDERS (index 0) ---
    // Cette option représente la valeur logique "Tous" mais est affichée comme l'en-tête.

    // Pays
    ui->comboBox_paysDepart->addItem("Pays"); // Placeholder visible
    ui->comboBox_paysArrivee->addItem("Pays");

    // Ville
    ui->comboBox_villeDepart->addItem("Ville"); // Placeholder visible
    ui->comboBox_villeArrivee->addItem("Ville");

    // Aéroport
    ui->comboBox_aeroportDepart->addItem("Aéroport"); // Placeholder visible
    ui->comboBox_aeroportArrivee->addItem("Aéroport");

    // --- Remplissage des options (à partir de l'index 1) ---

    // Pays
    while (queryPays.next()) {
        QString pays = queryPays.value(0).toString();
        ui->comboBox_paysDepart->addItem(pays);
        ui->comboBox_paysArrivee->addItem(pays);
    }

    // Villes
    while (queryVille.next()) {
        QString ville = queryVille.value(0).toString();
        ui->comboBox_villeDepart->addItem(ville);
        ui->comboBox_villeArrivee->addItem(ville);
    }

    // Aéroports
    while (queryAeroport.next()) {
        QString aeroport = queryAeroport.value(0).toString();
        ui->comboBox_aeroportDepart->addItem(aeroport);
        ui->comboBox_aeroportArrivee->addItem(aeroport);
    }

    // S'assurer que le placeholder (index 0) est sélectionné par défaut
    ui->comboBox_paysDepart->setCurrentIndex(0);
    ui->comboBox_paysArrivee->setCurrentIndex(0);
    ui->comboBox_villeDepart->setCurrentIndex(0);
    ui->comboBox_villeArrivee->setCurrentIndex(0);
    ui->comboBox_aeroportDepart->setCurrentIndex(0);
    ui->comboBox_aeroportArrivee->setCurrentIndex(0);
}

void MainWindow::naviguerVersAccueil()
{
    const int ACCUEIL_INDEX = 0;

    ui->tabWidget_gestion->setCurrentIndex(ACCUEIL_INDEX);
}

// Slot générique pour les boutons "Retour" (à connecter dans Qt Designer)
void MainWindow::on_pushButton_retour_clicked()
{
    // Appelle la fonction de navigation vers l'accueil
    naviguerVersAccueil();
}

void MainWindow::on_pushButton_retour_1_clicked()
{

}

